import java.util.Comparator;
import java.util.PriorityQueue;

public class AnotherBaconDegree implements Comparable<AnotherBaconDegree>{
	private String name;		 // which actor
	private Double degree;	 // number of costars
	
	public AnotherBaconDegree(String name, double degree) {
		this.name = name;
		this.degree = new Double(degree);
	}
	
	public AnotherBaconDegree(String name) {
		this.name = name;
	}
		
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDegree() {
		return degree;
	}

	public void setDegree(double degree) {
		this.degree = degree;
	}

	/**
	 * Comparable: just use String's version (lexicographic)
	 */
	@Override
	public int compareTo(AnotherBaconDegree b2) {
		return degree.compareTo(b2.degree);
	}
	

	@Override
	public String toString() {
		return name + " has degree of " + degree;
	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub		
	}

}
