import java.util.Comparator;
import java.util.PriorityQueue;

public class AnotherBaconSeparation implements Comparable<AnotherBaconSeparation>{
		private String name;		 // which actor
		private Double separation;	 // how far separated

		public AnotherBaconSeparation(String name, double separation) {
			this.name = name;
			this.separation = new Double(separation);
		}

		public double getSeparation() {
			return separation;
		}

		public String getName() {
			return name;
		}
		
		public void setSeparation(double separation) {
			this.separation = separation;
		}
		
		

		/**
		 * Comparable: just use String's version (lexicographic)
		 */
		@Override
		public int compareTo(AnotherBaconSeparation b2) {
			return separation.compareTo(b2.separation);
		}


		@Override
		public String toString() {
			return name + " has average separation of: " + separation;
		}

}
