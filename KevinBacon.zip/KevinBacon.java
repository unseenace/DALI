import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


public class KevinBacon {

	public static Map<String,String> createHelperMap (String filename) throws IOException {
		BufferedReader input;
		Map<String,String> helperMap = new TreeMap<String,String>();

		try {
			input = new BufferedReader(new FileReader(filename));
		}
		catch (FileNotFoundException e) {
			System.err.println("File cannot be opened.\n" + e.getMessage());
			return helperMap;
		}

		// Read the file
		try {

			// Create the character|frequency map
			String line;
			while ((line = input.readLine()) != null) {

				String[] splitted = line.split("\\|");
				helperMap.put(splitted[0], splitted[1]);	
			}

		}

		finally {
			// Close file if possible
			try {
				input.close();
			}
			catch (IOException e) {
				System.err.println("File cannot be closed.\n" + e.getMessage());
			}		
		}
		return helperMap;
	}

	public static Map<String,List<String>> createMovie_ActorListMap (Map<String,String> ID_MovieName, Map<String,String> ID_ActorName, String filename) throws IOException {
		BufferedReader input;
		Map<String,List<String>> mapOfMovie_ActorList = new TreeMap<String,List<String>>();
		List<String> movieList = new ArrayList<String>();

		// Put in movie names as keys in the map first
		for (String movieID : ID_MovieName.keySet()) {
			mapOfMovie_ActorList.put(ID_MovieName.get(movieID), movieList);			
		}

		try {
			input = new BufferedReader(new FileReader(filename));
		}
		catch (FileNotFoundException e) {
			System.err.println("File cannot be opened.\n" + e.getMessage());
			return mapOfMovie_ActorList;
		}

		// Read the file
		try {

			String line;
			while ((line = input.readLine()) != null) {
				List<String> temp = new ArrayList<String>();

				String[] splitted = line.split("\\|");
				String movie_ID = splitted[0];
				String actor_ID = splitted[1];

				// If this movie has no actors, add the actor to the list (value of map)
				if (mapOfMovie_ActorList.get(ID_MovieName.get(movie_ID)).isEmpty()) {
					temp.add(ID_ActorName.get(actor_ID));
					mapOfMovie_ActorList.put(ID_MovieName.get(movie_ID), temp);
				}

				// Otherwise, update list by adding new actor
				else if (!mapOfMovie_ActorList.get(ID_MovieName.get(movie_ID)).isEmpty()) {
					temp = mapOfMovie_ActorList.get(ID_MovieName.get(movie_ID));
					temp.add(ID_ActorName.get(actor_ID));
					mapOfMovie_ActorList.put(ID_MovieName.get(movie_ID), temp);
				}					
			}
		}

		finally {
			// Close file if possible
			try {
				input.close();
			}
			catch (IOException e) {
				System.err.println("File cannot be closed.\n" + e.getMessage());
			}		
		}
		return mapOfMovie_ActorList;
	}


	public static Map<String,HashSet<String>> createMovie_ActorSetMap (Map<String,String> ID_MovieName, Map<String,String> ID_ActorName, String filename) throws IOException {
		BufferedReader input;
		Map<String,HashSet<String>> mapOfMovie_ActorSet = new TreeMap<String,HashSet<String>>();
		HashSet<String> movieSet = new HashSet<String>();

		// Put in movie names as keys in the map first
		for (String movieID : ID_MovieName.keySet()) {
			mapOfMovie_ActorSet.put(ID_MovieName.get(movieID), movieSet);			
		}

		try {
			input = new BufferedReader(new FileReader(filename));
		}
		catch (FileNotFoundException e) {
			System.err.println("File cannot be opened.\n" + e.getMessage());
			return mapOfMovie_ActorSet;
		}

		// Read the file
		try {
			String line;
			while ((line = input.readLine()) != null) {
				HashSet<String> temp = new HashSet<String>();
				String[] splitted = line.split("\\|");
				String movie_ID = splitted[0];
				String actor_ID = splitted[1];

				// If this movie has no actors, add the actor to the list (value of map)
				if (mapOfMovie_ActorSet.get(ID_MovieName.get(movie_ID)).isEmpty()) {
					temp.add(ID_ActorName.get(actor_ID));
					mapOfMovie_ActorSet.put(ID_MovieName.get(movie_ID), temp);
				}

				// Otherwise, update list by adding new actor
				else if (!mapOfMovie_ActorSet.get(ID_MovieName.get(movie_ID)).isEmpty()) {
					temp = mapOfMovie_ActorSet.get(ID_MovieName.get(movie_ID));
					temp.add(ID_ActorName.get(actor_ID));
					mapOfMovie_ActorSet.put(ID_MovieName.get(movie_ID), temp);
				}					
			}
		}

		finally {
			// Close file if possible
			try {
				input.close();
			}
			catch (IOException e) {
				System.err.println("File cannot be closed.\n" + e.getMessage());
			}		
		}
		return mapOfMovie_ActorSet;
	}

	// Build the undirected graph
	public static <V,E> Graph <V,Set<V>> buildGraphOf_Actor_SetOfMovies(Map<V,List<V>> movie_CommonActors_Map, Map<V,V> ID_ActorName) {

		Graph<V,Set<V>> result = new AdjacencyMapGraph<V,Set<V>>();

		// Add vertices to graph
		V currentFirstActor;
		for (V actor : ID_ActorName.keySet()) {
			currentFirstActor = ID_ActorName.get(actor);
			result.insertVertex(currentFirstActor);
		}

		// Loop over all movies, forming edges between common actors
		for (V movie : movie_CommonActors_Map.keySet()) {

			if (!movie_CommonActors_Map.get(movie).isEmpty()) {

				// Traverse each actor within movie
				for (int i = 0; i < movie_CommonActors_Map.get(movie).size(); i++) {

					Stack<V> coactorsInMovie = new Stack<V>();

					// How many actors (set) in this movie 
					int numActors = movie_CommonActors_Map.get(movie).size();

					V vertexA; // Constant actor
					V vertexB;	// Variable actor

					// Counter to track self
					int o = i;
					// Counter to track all neighbors in front of self
					int m = i;

					// Push all actors except first onto stack
					while (m < numActors - 1) {
						coactorsInMovie.push(movie_CommonActors_Map.get(movie).get(m+1));
						//					System.out.println(movie_CommonActors_Map.get(movie).get(m+1));
						m++;
					}

					// While stack still got something in there, take it out and make a vertex pair
					while (!coactorsInMovie.isEmpty()) {
						vertexA = movie_CommonActors_Map.get(movie).get(o);
						vertexB = coactorsInMovie.pop();

						if (!vertexA.equals(null) || !vertexB.equals(null) ) {


							// First common movie
							if (result.getLabel(vertexA, vertexB) == null) {
								Set<V> commonMovies = new HashSet<V>();
								commonMovies.add(movie);	
								result.insertUndirected(vertexA, vertexB, commonMovies);							
							}

							// Modify common movies
							else if (!result.getLabel(vertexA, vertexB).isEmpty()) {
								Set<V> commonMovies = new HashSet<V>();
								commonMovies = result.getLabel(vertexA, vertexB);
								commonMovies.add(movie);
								result.insertUndirected(vertexA, vertexB, commonMovies);														

							}

						}
					}
				}
			}
		}	
		return result;
	}

	// Returns trail from origin to destination
	public static <V, E> Graph<V,E> bfs(Graph<V,E> g, V source) {

		// Resulting graph
		Graph<V, E> directedBFS = new AdjacencyMapGraph<V,E>();
		directedBFS.insertVertex(source);

		// Enqueue start vertex
		Queue<V> q = new LinkedList<V>();

		q.add(source);

		TreeMap<V,V> backpointerMap = new TreeMap<V,V>(); 

		backpointerMap.put(source, null);

		// Proceed as long as got something in queue
		while (!q.isEmpty()) {
			// Extract head of queue (should already have its back pointer adjusted when added to queue)
			V currentVertex;
			currentVertex = q.remove();

			// For all neighbors of recently removed head of queue
			for (V neighbor : g.outNeighbors(currentVertex)) {

				// Handle head case
				if (currentVertex.equals(source) ) {

					// Mark as added and visited
					q.add(neighbor);
					backpointerMap.put(neighbor, currentVertex);

					// Save who points to whom
					V pointee = currentVertex;
					V pointer = neighbor;
					E saveLabel = g.getLabel(pointer, pointee);

					directedBFS.insertVertex(pointer);

					// Update new graph
					directedBFS.insertDirected(pointer, pointee, saveLabel);
				}

				// If not yet already add to queue before, do it now (not existing in back pointer map yet)
				if (!backpointerMap.containsKey(neighbor) &&  !currentVertex.equals(source))  {

					// Mark as added and visited
					q.add(neighbor);
					backpointerMap.put(neighbor, currentVertex);

					// Save who points to whom
					V pointee = currentVertex;
					V pointer = neighbor;
					E saveLabel = g.getLabel(pointer, pointee);

					directedBFS.insertVertex(pointer);

					// Update new graph
					directedBFS.insertDirected(pointer, pointee, saveLabel);					
				}
			}
		}
		return directedBFS;
	}	


	public static <V,E> List<V> getPath(Graph<V, E> tree, V v) {

		// Result list
		List<V> trail = new ArrayList<V>();
	
		// Continue while vertex is pointing to someone
		while (tree.outDegree(v) == 1) {
			// Add to list who vertex is pointing to 
			for (V out : tree.outNeighbors(v)) {
				trail.add(out);

				// Update current to be next actor closer to the Kevin Bacon
				v = out;
			}
		}
		return trail;
	}

	public static <V,E> Set<V> missingVertices(Graph<V,E> graph, Graph<V,E> subgraph) {
		Set<V> missingSet = new HashSet<V>();

		// Check all vertices in main graph
		for (V vertexInMainGraph : graph.vertices()) {			

			// Remove those not pointing to someone and has no one pointing to it
			if (!subgraph.hasVertex(vertexInMainGraph)) {

				missingSet.add(vertexInMainGraph);
			}
		}
		return missingSet;
	}

	// Average distance from root in shortest path tree
	public static <V,E> double averageSeparation(Graph<V,E> tree, V root) {
		// Base case when one has no out neighbors pointing to it
		double baconSum;
		double quantityActors;
		quantityActors = tree.numVertices();

		baconSum = averageSeparationHelper(tree, root, 0);

		return (baconSum / quantityActors);
	}

	public static <V,E> double averageSeparationHelper(Graph<V,E> tree, V currentRoot, double runningSum) {

		double newSum = runningSum ;

		// Recurse each actor pointing to me until no one is pointing to it
		for (V childOfCurrent : tree.inNeighbors(currentRoot)) {
			newSum +=  averageSeparationHelper(tree, childOfCurrent, runningSum + 1);
		}

		return newSum;
	}

	// Find other 'Bacons' by conducting BFS short tree on each actor and arrange according to degree (number of co-stars) 
	public static List<AnotherBaconSeparation> getOtherBaconsAverageSeparation(Graph<String,Set<String>> undirectedGraph, Graph<String,Set<String>> directedGraph) {
		Graph<String,Set<String>> otherBaconGraph = new AdjacencyMapGraph<String,Set<String>>();
		Graph<String,Set<String>> filteredGraph = new AdjacencyMapGraph<String,Set<String>>();

		List<AnotherBaconSeparation> baconSeparationList= new ArrayList<AnotherBaconSeparation>();


		for (String vertex : undirectedGraph.vertices()) {

			// Don't BFS anything unnecessary
			if (!missingVertices(undirectedGraph, directedGraph).contains(vertex)) {

				otherBaconGraph = bfs(undirectedGraph, vertex);
				double currentBaconPathAverage = averageSeparation(otherBaconGraph, vertex);
				AnotherBaconSeparation baconSeparation = new AnotherBaconSeparation(vertex, currentBaconPathAverage);
				baconSeparationList.add(baconSeparation);

			}

		}

		return baconSeparationList;
	}


	public static List<AnotherBaconSeparation> sortBaconSeparations (List<AnotherBaconSeparation> toSortSeparationsList) {
		PriorityQueue<AnotherBaconSeparation> separationPQ = new PriorityQueue<AnotherBaconSeparation>();
		List<AnotherBaconSeparation> SeparationListBacon = new ArrayList<AnotherBaconSeparation>();

		// Use a custom Comparator to compare (degree)
		class SeparationLengthComparator implements Comparator<AnotherBaconSeparation> {
			public int compare(AnotherBaconSeparation bd1, AnotherBaconSeparation bd2) {
				double differenceInSeparation = bd1.getSeparation() - bd2.getSeparation();
				if (differenceInSeparation > 0) return 1;
				if (differenceInSeparation < 0) return -1;
				return 0;
			}
		}

		// Make a sorted list (ascending order) of degree
		Comparator<AnotherBaconSeparation> separationCompare = new SeparationLengthComparator();
		separationPQ = new PriorityQueue<AnotherBaconSeparation>(separationCompare);
		separationPQ.addAll(toSortSeparationsList);		
		while (!separationPQ.isEmpty()) SeparationListBacon.add(separationPQ.remove());

		return SeparationListBacon;
	}

	//	public static Map<String, Double> getOtherBaconsDegree(Graph<String,Set<String>> undirectedGraph) {
	public static List<AnotherBaconDegree> getOtherBaconsDegree(Graph<String,Set<String>> undirectedGraph) {


		List<AnotherBaconDegree> baconDegreeList= new ArrayList<AnotherBaconDegree>();
		// Loop through all vertices in given undirected graph, BFS it, then calculate the in-degree of each vertex
		for (String vertex : undirectedGraph.vertices()) {

			double currentDegree = undirectedGraph.inDegree(vertex);
			AnotherBaconDegree baconDegree = new AnotherBaconDegree(vertex, currentDegree);
			baconDegreeList.add(baconDegree);
		}
		return baconDegreeList;
	}

	public static List<AnotherBaconDegree> sortBaconDegrees (List<AnotherBaconDegree> toSortDegreesList) {
		PriorityQueue<AnotherBaconDegree> degreePQ = new PriorityQueue<AnotherBaconDegree>();
		List<AnotherBaconDegree> DegreeListBacon = new ArrayList<AnotherBaconDegree>();

		// Use a custom Comparator to compare (degree)
		class DegreeLengthComparator implements Comparator<AnotherBaconDegree> {
			public int compare(AnotherBaconDegree bd1, AnotherBaconDegree bd2) {
				double differenceInDegree = bd1.getDegree() - bd2.getDegree();
				if (differenceInDegree > 0) return 1;
				if (differenceInDegree < 0) return -1;
				return 0;
			}
		}

		// Make a sorted list (ascending order) of degree
		Comparator<AnotherBaconDegree> degreeCompare = new DegreeLengthComparator();
		degreePQ = new PriorityQueue<AnotherBaconDegree>(degreeCompare);
		degreePQ.addAll(toSortDegreesList);		
		while (!degreePQ.isEmpty()) DegreeListBacon.add(degreePQ.remove());

		return DegreeListBacon;
	}

	private static void printOpeningMessage() {
		System.out.println("Commands:");
		System.out.println("c <#>                   : List top/bottom <#> centers of universe sorted by avg. separation");
		System.out.println("d <low> <high> : List actors sorted by degree, with degree between low and high");
		System.out.println("i                           : List actors with infinite separation from current center");
		System.out.println("p <name>           : Find path from <name> to current center of universe");
		System.out.println("s <low> <high>  : List actors sorted by non-infinite separation from current center, with separation between low and high");
		System.out.println("u <name>           : Make <name> center of universe");
		System.out.println("b                          : Get real Kevin Bacon's data (very slow) ");
		System.out.println("t                           : Total number of actors connected via someone to the center");
		System.out.println("q                          : Quit");
		System.out.println("\n");
	}

	public static void main (String[] args) throws Exception {

		// General undirected graph
		Graph<String,Set<String>> undirectedGraph_ActorName_SetMovieNames;		
		// Main directed graph for specified source
		Graph<String,Set<String>> directedGraph_ActorName_SetMovieNames;
		// Set of missing vertices
		Set<String> missingVertices;
		// Helper map to build main graph
		Map<String,List<String>> movie_CommonActors_Map;

		// Final Path from end to origin
		List<String> trail = new ArrayList<String>();

		// Bacon Degree List of other Bacons
		List<AnotherBaconDegree> BaconDegreeList = new ArrayList<AnotherBaconDegree>();
		List<AnotherBaconDegree> SortedBaconDegreeList = new ArrayList<AnotherBaconDegree>();
		// Bacon Separation List of other Bacons
		List<AnotherBaconSeparation> BaconSeparationList = new ArrayList<AnotherBaconSeparation>();
		List<AnotherBaconSeparation> SortedBaconSeparationList = new ArrayList<AnotherBaconSeparation>();

		// Helper Maps
		Map<String,String> ID_ActorName;
		Map<String,String> ID_MovieName;
		Map<String,String> IDMovie_IDActor;

		String center = "Kevin Bacon";


		// Maps ID (key) to ActorName (value)
		//		ID_ActorName = createHelperMap("bacon/actorsTest.txt");
		ID_ActorName = createHelperMap("bacon/actors.txt");

		// Maps ID (key) to MovieName (value)
		//		ID_MovieName = createHelperMap("bacon/moviesTest.txt");
		ID_MovieName = createHelperMap("bacon/movies.txt");

		// Maps MovieID (key) to ActorID (value)
		//		IDMovie_IDActor = createHelperMap("bacon/movie-actorsTest.txt");
		IDMovie_IDActor = createHelperMap("bacon/movie-actors.txt");


		// Build helper map [keys:values of movie:list of actors] to help build main graph
		//		movie_CommonActors_Map = createMovie_ActorListMap(ID_MovieName, ID_ActorName, "bacon/movie-actorsTest.txt");
		movie_CommonActors_Map = createMovie_ActorListMap(ID_MovieName, ID_ActorName, "bacon/movie-actors.txt");

		// Create the undirected graph
		undirectedGraph_ActorName_SetMovieNames = buildGraphOf_Actor_SetOfMovies(movie_CommonActors_Map,ID_ActorName);

		// Main BFS graph for source
		directedGraph_ActorName_SetMovieNames = bfs(undirectedGraph_ActorName_SetMovieNames, center);



		// Return set of vertices not in subgraph after BFS-ing
		missingVertices = missingVertices(undirectedGraph_ActorName_SetMovieNames, directedGraph_ActorName_SetMovieNames);

		// Get sorted List of vertices by in degrees (popularity in ascending order)
		BaconDegreeList = getOtherBaconsDegree(undirectedGraph_ActorName_SetMovieNames);
		SortedBaconDegreeList = sortBaconDegrees(BaconDegreeList);
		for (AnotherBaconDegree bacon : BaconDegreeList) {
			if (bacon.getName().equals(center)) System.out.println("Kevin Bacon's degree is : " + bacon.getDegree());
		}


		System.out.println(SortedBaconSeparationList);
		System.out.println("Loaded..\n");

		// Hard Coded Test Case
		Graph<String, Set<String>> testCase = new AdjacencyMapGraph<String, Set<String>>();
		Set<String> testSetA = new TreeSet<String>();
		Set<String> testSetAE = new TreeSet<String>();
		Set<String> testSetC = new TreeSet<String>();
		Set<String> testSetD = new TreeSet<String>();
		Set<String> testSetB = new TreeSet<String>();
		Set<String> testSetF = new TreeSet<String>();

		testSetA.add("A Movie");
		testSetAE.add("A Movie");
		testSetAE.add("E Movie");
		testSetC.add("C Movie");
		testSetD.add("D Movie");
		testSetB.add("B Movie");
		testSetF.add("F Movie");
		testSetAE.add("E Movie");

		testCase.insertVertex("Kevin Bacon");
		testCase.insertVertex("Alice");
		testCase.insertVertex("Bob");
		testCase.insertVertex("Charlie");
		testCase.insertVertex("Dartmouth (Earl thereof)");
		testCase.insertVertex("Nobody");
		testCase.insertVertex("Nobody's friend");

		testCase.insertUndirected("Kevin Bacon", "Alice", testSetAE);
		testCase.insertUndirected("Kevin Bacon", "Bob", testSetA);
		testCase.insertUndirected("Alice", "Bob", testSetA);
		testCase.insertUndirected("Alice", "Charlie", testSetD);
		testCase.insertUndirected("Bob", "Charlie", testSetC);
		testCase.insertUndirected("Dartmouth (Earl thereof)", "Charlie", testSetB);
		testCase.insertUndirected("Nobody", "Nobody's friend", testSetF);

		System.out.println("Printing the hard coded test case after BFS");
		System.out.println(bfs(testCase, "Kevin Bacon"));


		// Start inputs of text to display screen
		boolean running = true;

		while (running) {
			Scanner in = new Scanner(System.in);
			System.out.println("\nWelcome to the " + center + " Game!");
			printOpeningMessage();			
			String line = in.nextLine();
			String[] terms = line.split(" ");

			// Quit game
			if (terms[0].equals("q")) {
				System.out.println("Game exited...");
				running = false;
			}

			// Total number of actors connected via someone to the center 
			if (terms[0].equals("t")) {
				int howManyActorsConnected = 0;
				for (String vertex : undirectedGraph_ActorName_SetMovieNames.vertices()) {

					// Don't BFS anything unnecessary
					if (!missingVertices(undirectedGraph_ActorName_SetMovieNames, directedGraph_ActorName_SetMovieNames).contains(vertex)) {
						howManyActorsConnected++;
					}
				}
				System.out.println("There are " + howManyActorsConnected + " people connected to the center (" + center + ") of this graph" );
			}

			// Print Kevin Bacon data
			if (terms[0].equals("b")) {
				BaconDegreeList = getOtherBaconsDegree(undirectedGraph_ActorName_SetMovieNames);
				SortedBaconDegreeList = sortBaconDegrees(BaconDegreeList);
				for (AnotherBaconDegree bacon : BaconDegreeList) {
					if (bacon.getName().equals(center)) System.out.println("Kevin Bacon's degree is : " + bacon.getDegree());
				}
				BaconSeparationList = getOtherBaconsAverageSeparation(undirectedGraph_ActorName_SetMovieNames, directedGraph_ActorName_SetMovieNames);
				for (AnotherBaconSeparation actor_Separation: BaconSeparationList) {

					if (actor_Separation.getName().equals("Kevin Bacon")) {
						System.out.println("Kevin Bacon's separation is : " + actor_Separation.getSeparation());
					}

				}
			}

			// List actors with infinite separation from current center
			if (terms[0].equals("i")) {
				System.out.println("These are the people with infinite " + center + " number");
				missingVertices = missingVertices(undirectedGraph_ActorName_SetMovieNames, directedGraph_ActorName_SetMovieNames);

				for (String missing : missingVertices) {

					System.out.println(missing);
				}
			}

			// Find path from <name> to current center of universe
			if (terms.length > 1) {
				if (terms[0].equals("p")) {

					// Format who is end actor
					String fullName = "";
					for (int i=1; i < terms.length; i++) {
						fullName += terms[i];
						fullName += " ";
					}
					fullName = fullName.substring(0,fullName.length() - 1);
					String endActor = fullName;

					// Proceed if actor is legitimate
					if (directedGraph_ActorName_SetMovieNames.hasVertex(endActor)) {
						trail = getPath(directedGraph_ActorName_SetMovieNames, endActor);

						String current = endActor;
						System.out.println("The " + center + " number of " + endActor + " is " + trail.size());
						System.out.println();
						for (int i = 0; i < getPath(directedGraph_ActorName_SetMovieNames, endActor).size(); i++) {
							System.out.println(current + " starred in " + directedGraph_ActorName_SetMovieNames.getLabel(current, trail.get(i)) + " with " + trail.get(i));
							current = getPath(directedGraph_ActorName_SetMovieNames, endActor).get(i);
						}
					}
					else {
						System.out.println(endActor + " is not connected to the center of this universe");
					}

				}

				// Make <name> center of universe
				if (terms[0].equals("u")) {
					// Format who is new center
					String fullName = "";
					for (int i=1; i < terms.length; i++) {
						fullName += terms[i];
						fullName += " ";
					}
					fullName = fullName.substring(0,fullName.length() - 1);
					String newCenter = fullName;
					if (undirectedGraph_ActorName_SetMovieNames.hasVertex(newCenter)) {
						System.out.println("The new center has been changed to: " + newCenter);
						center = newCenter;
						directedGraph_ActorName_SetMovieNames = bfs(undirectedGraph_ActorName_SetMovieNames, newCenter);
					}
				}

				if (terms[0].equals("u")) {
					String fullName = "";
					for (int i=1; i < terms.length; i++) {
						fullName += terms[i];
						fullName += " ";
					}
					fullName = fullName.substring(0,fullName.length() - 1);
				}
			}

			if (terms.length == 2) {

				// List top/bottom <#> centers of universe sorted by avg. separation
				if (terms[0].equals("c")) {
					Integer bound = Integer.parseInt(terms[1]);
					BaconSeparationList = getOtherBaconsAverageSeparation(undirectedGraph_ActorName_SetMovieNames, directedGraph_ActorName_SetMovieNames);
					SortedBaconSeparationList = sortBaconSeparations(BaconSeparationList);

					System.out.println("Here are the " + bound +" top and bottom " + "" + "centers of the universe ( " + "" + " ) sorted by average separation");
					System.out.println("Top...");
					// Top centers of universe by separation
					for (int i = 0; i < bound; i++) {
						System.out.println("" + (i+1) + ") " + SortedBaconSeparationList.get(i));
					}
					System.out.println("\nBottom...");
					// Bottom centers of universe by separation
					Collections.reverse(SortedBaconSeparationList);
					for (int i = 0; i < bound; i++) {
						System.out.println("" + (i+1) + ") " + SortedBaconSeparationList.get(i));
					}
				}
			}

			if (terms.length == 3) {

				// List actors sorted by degree, with degree between low and high
				if (terms[0].equals("d")) {
					Double lowBound = Double.parseDouble(terms[1]);
					Double  upBound = Double.parseDouble(terms[2]);
					System.out.println("Here are all the actors with degree of between " + lowBound + " and " + upBound);
					BaconDegreeList = getOtherBaconsDegree(undirectedGraph_ActorName_SetMovieNames);
					SortedBaconDegreeList = sortBaconDegrees(BaconDegreeList);
					for (AnotherBaconDegree actor_Degree: SortedBaconDegreeList) {
						if (actor_Degree.getDegree() >= lowBound && actor_Degree.getDegree() <= upBound) {
							System.out.println(actor_Degree);
						}
					}
				}

				// List actors sorted by non-infinite separation from current center, with separation between low and high
				if (terms[0].equals("s")) {
					System.out.println("executing");
					BaconSeparationList = getOtherBaconsAverageSeparation(undirectedGraph_ActorName_SetMovieNames, directedGraph_ActorName_SetMovieNames);
					Double lowBound = Double.parseDouble(terms[1]);
					Double  upBound = Double.parseDouble(terms[2]);
					System.out.println("Here are all the actors with degree of between " + lowBound + " and " + upBound);
					for (AnotherBaconSeparation actor_Separation: BaconSeparationList) {

						if (actor_Separation.getSeparation() >= lowBound && actor_Separation.getSeparation() <= upBound) {
							System.out.println(actor_Separation);
						}
					}
				}

				else {
					System.out.println("");
				}
			}
		}
	}
}



