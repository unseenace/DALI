/**
 * CS 10, Lab Assignment III 
 * Due 19 October 2016
 * Author: Colin GUI
 * 
 * Code discussed with Kevin Tan
 */

import java.util.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class HuffmanReader {

	// US Constitution
	private static final String US = "inputs/USConstitution.txt";
	private static final String USC = "inputs/USConstitution_compressed.txt";
	private static final String USD = "inputs/USConstitution_decompressed.txt";

	// War And Peace
	private static final String WP = "inputs/WarAndPeace.txt";
	private static final String WPC = "inputs/WarAndPeace_compressed.txt";
	private static final String WPD = "inputs/WarAndPeace_decompressed.txt";

	// Empty File Case
	private static final String EMPTY = "inputs/EmptyFile.txt";
	private static final String EMPTYC = "inputs/EmptyFile_compressed.txt";
	private static final String EMPTYD = "inputs/EmptyFile_decompressed.txt";

	// Single character edge case
	private static final String SINGLE = "inputs/SingleCharacter.txt";
	private static final String SINGLEC = "inputs/SingleCharacter_compressed.txt";
	private static final String SINGLED = "inputs/SingleCharacter_decompressed.txt";
	
	// Small test case
	private static final String SMALL = "inputs/SmallTestCase.txt";
	private static final String SMALLC = "inputs/SmallTestCase_compressed.txt";
	private static final String SMALLD = "inputs/SmallTestCase_decompressed.txt";

	// Takes as parameter the main Huffman tree, and returns a map of its decoded characters
	private static Map<Character,String> getCodes(BinaryTree<CharacterFrequency> mainTree) {

		// Create Map of character|frequency to store character and its corresponding string representation codes
		Map<Character,String> decodedMap = new TreeMap<Character,String>();

		// For traversing left child
		String ss0 = new String("0");
		// For traversing right child
		String ss1 = new String("1");
		// Neutral node/parent
		String sss = new String("");

		// Call helper method to add keys and values to map
		getCodesHelper(decodedMap, mainTree, ss0, ss1, sss);

		return decodedMap;
	}

	// Helper method to add characters|codes (string form) to map
	private static void getCodesHelper(Map<Character,String> helperMap, BinaryTree<CharacterFrequency> mainTree, String s0, String s1, String s) {

		// Handle empty file case
		if (mainTree == null) {
			System.err.println("This file is an empty file");
			return;
		}

		// This is a character, add it to the map (Base Case)
		if (mainTree.isLeaf()) {
			helperMap.put(mainTree.getData().getCharacter(), s);
		}

		// Recurse left subtree
		if (mainTree.hasLeft()) {
			getCodesHelper(helperMap, mainTree.getLeft(), s0, s1, s + s0);
		}

		// Recurse right subtree
		if (mainTree.hasRight()) {
			getCodesHelper(helperMap, mainTree.getRight(), s0, s1, s + s1);
		}
	}

	// Generate the character|frequency map
	private static Map<Character,Integer> createCharFreqMap(String filename) throws IOException {

		// Create and initialize tree to return character|frequency map 
		Map<Character, Integer> charAndFreqMap = new TreeMap<Character, Integer>();

		// Prepare to read character file
		BufferedReader input;

		// Open file if possible
		try {
			input = new BufferedReader(new FileReader(filename));
		} 
		catch (FileNotFoundException e) {
			System.err.println("File cannot be opened.\n" + e.getMessage());
			return charAndFreqMap;
		}

		// Read the file
		try {

			// Create the character|frequency map
			int r;
			while ((r = input.read()) != -1) {
				char c = (char) r;

				// Increment frequency count if character already in map
				if (charAndFreqMap.containsKey(c)) {
					charAndFreqMap.put(c, charAndFreqMap.get(c) + 1);
				}
				// Add character if not already in map
				else {
					charAndFreqMap.put(c, 1);
				}		
			}

		}

		finally {

			// Close file if possible
			try {
				input.close();
			}
			catch (IOException e) {
				System.err.println("File cannot be closed.\n" + e.getMessage());
			}		
		}
		return charAndFreqMap;
	}

	// Form the PQ consisting of BinaryTrees holding data of custom class (Character|Frequency)
	private static PriorityQueue<BinaryTree<CharacterFrequency>> addTreesToPQ(Map<Character,Integer> charFreqMap) {

		CharacterFrequency dataOfCharAndFreq;
		BinaryTree<CharacterFrequency> treeOfCharAndFreq;
		PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQue;

		// Comparator implementor
		charAndFreqPriQue = new PriorityQueue<BinaryTree<CharacterFrequency>>((BinaryTree<CharacterFrequency> bt1, BinaryTree<CharacterFrequency> bt2) -> bt1.data.getFrequency() - bt2.data.getFrequency());

		// Add trees to priority queue
		for (Character ch : charFreqMap.keySet()) {

			// Custom helper class holds character and frequency
			dataOfCharAndFreq = new CharacterFrequency(ch, charFreqMap.get(ch));

			// Pass instance of custom class to 'data' of BinaryTree
			treeOfCharAndFreq = new BinaryTree<CharacterFrequency>(dataOfCharAndFreq);

			// Add this to priority queue
			charAndFreqPriQue.add(treeOfCharAndFreq);

		}
		return charAndFreqPriQue;
	}

	// Merge trees in PQ to form one final HuffmanTree
	private static void createHuffmanTree(PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQue) {

		// Handle case of only one character in file
		if (charAndFreqPriQue.size() == 1) {

			System.out.println("Only one character detected in this file");

			// Get data of the only tree in the PQ holding the singular character in file
			BinaryTree<CharacterFrequency> onlyCharacter = charAndFreqPriQue.remove();

			// Arbitrary character for head of HuffmanTree
			Character blank = new Character('Q');
			// Use for frequency of head the frequency of the singular character in file 
			int headFrequency = onlyCharacter.data.getFrequency();
			// Create custom class character|frequency to assign it to the 'data' of BinaryTree
			CharacterFrequency dataOfHead = new CharacterFrequency(blank, headFrequency);

			// Add frequency|character BinaryTree to left child (arbitrary) of head of HuffmanTree
			BinaryTree<CharacterFrequency> arbitraryHead = new BinaryTree<CharacterFrequency>(dataOfHead, onlyCharacter, null);

			// Dump this single tree (HuffmanTree) back to the PQ
			charAndFreqPriQue.add(arbitraryHead);					
		}

		// Regular case
		while (charAndFreqPriQue.size() > 1) {

			// Remove smallest two trees to be combined into one tree
			BinaryTree<CharacterFrequency> firstRemovedTree;
			BinaryTree<CharacterFrequency> secondRemovedTree;
			firstRemovedTree = charAndFreqPriQue.remove();
			secondRemovedTree = charAndFreqPriQue.remove();

			// Obtain sum of character frequencies of smallest two trees
			int sumOfFrequencies = firstRemovedTree.data.getFrequency() + secondRemovedTree.data.getFrequency();

			// New tree with no character gets assigned arbitrary 'Q'
			Character blank = new Character('Q');

			// Create the new tree
			CharacterFrequency dataOfNewTree = new CharacterFrequency(blank, sumOfFrequencies);
			BinaryTree<CharacterFrequency> newTree = new BinaryTree<CharacterFrequency>(dataOfNewTree, firstRemovedTree, secondRemovedTree);

			// Dump newly created tree back into PriorityQueue, before repeating previous steps to produce one final Huffman tree
			charAndFreqPriQue.add(newTree);
		}
	}

	// Characters to bits
	private static void compressHuffman(String readCharFile, String writeBitFile, Map<Character,String> huffmanCodeMap) throws IOException {

		// Prepare to read character file
		BufferedReader input;
		// Prepare to write bits into file
		BufferedBitWriter bitOutput = new BufferedBitWriter(writeBitFile);


		// Open file if possible
		try {
			input = new BufferedReader(new FileReader(readCharFile));
		} 
		catch (FileNotFoundException e) {
			System.err.println("File cannot be opened.\n" + e.getMessage());
			return;
		}

		// Read the file
		try {

			// Create the character|frequency map
			int r;
			while ((r = input.read()) != -1) {

				// Get the code value of a character
				char c = (char) r;
				String codeString = huffmanCodeMap.get(c);

				// Singularly bit-write each character in the given string value
				for (int i = 0; i < codeString.length(); i++) {
					// Partition off each character in the string, writing a bit for it one by one
					String toWrite = new String (codeString.substring(i, i+1));

					// 0 is false, 1 is true
					if (toWrite.equals(new String("0"))) bitOutput.writeBit(false);
					else bitOutput.writeBit(true);		
				}
			}
		}

		finally {

			// Close file if possible
			try {
				input.close();
				bitOutput.close();
			}
			catch (IOException e) {
				System.err.println("File cannot be closed.\n" + e.getMessage());
			}		
		}
	}

	// Bits to characters
	private static void decompressHuffman(String readBitFile, String writeCharFile, BinaryTree<CharacterFrequency> huffmanTree) throws IOException {

		// Store main HuffmanTree in a holder to help check leaf nodes when decoding bits
		BinaryTree<CharacterFrequency> checkCurrentTree = huffmanTree;

		// Prepare to read bit file
		BufferedBitReader bitInput;
		// Prepare to write characters into file
		BufferedWriter output = new BufferedWriter(new FileWriter(writeCharFile));

		// Open file if possible
		try {
			bitInput = new BufferedBitReader(readBitFile);
		} 
		catch (FileNotFoundException e) {
			System.err.println("File cannot be opened.\n" + e.getMessage());
			output.close();
			return;
		}

		// Write characters into file after decoding bits
		try {

			while (bitInput.hasNext()) {
				boolean bit = bitInput.readBit();

				// 0 is false, 1 is true
				if (bit) checkCurrentTree = checkCurrentTree.getRight();
				else checkCurrentTree = checkCurrentTree.getLeft();

				// Reset to root/top of HuffmanTree to decode next character
				if (checkCurrentTree.isLeaf()) {
					Character toWrite = new Character(checkCurrentTree.getData().getCharacter());
					output.write(toWrite);
					checkCurrentTree = huffmanTree;
				}
			}
		}

		finally {

			// Close file if possible
			try {
				bitInput.close();
				output.close();
			}
			catch (IOException e) {
				System.err.println("File cannot be closed.\n" + e.getMessage());
			}		
		}
	}


	// Following four methods are test cases to print maps, trees, and pq that can be called in main
	private static void testCharFreqMap(Map<Character, Integer> charAndFreqMap) {
		System.out.println("Printing size of character|frequency map");
		System.out.println(charAndFreqMap.size());
		System.out.println("Printing character|frequency map...");
		System.out.println(charAndFreqMap);
		for (Character c : charAndFreqMap.keySet()) {
			System.out.println( "*" + c + "*" + charAndFreqMap.get(c)  );
		}
	}

	private static void testCharAndFreqPriQue(PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQue) {
		System.out.println("\nPrinting the trees in PQ...");
		System.out.println(charAndFreqPriQue);
	}

	private static void testHuffmanTree(PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQue) {
		BinaryTree<CharacterFrequency> ujian;
		ujian = charAndFreqPriQue.peek();
		System.out.println("\nPrinting the HuffmanTree (testing the PQ)...");
		System.out.println(ujian);	
	}

	private static void testHuffmanCodeMap(Map<Character,String> huffmanCodeMap) {
		System.out.println("Printing the Huffman Code Map..");
		System.out.println(huffmanCodeMap);
	}

	// Main
	public static void main(String[] args) throws Exception {

		// The character|frequency map
		Map<Character, Integer> charAndFreqMapTestSmall; // small test case
		Map<Character, Integer> charAndFreqMapTestSingle; // single character edge case
		Map<Character, Integer> charAndFreqMapTestEmpty; // empty file
		Map<Character, Integer> charAndFreqMapUS; // US Constitution
		Map<Character, Integer> charAndFreqMapWP; // War & Peace

		// Map of character|code represented in string of bits
		Map<Character,String> huffmanCodeMapTestSmall; // small test case
		Map<Character,String> huffmanCodeMapTestSingle; // single character edge case
		Map<Character,String> huffmanCodeMapTestEmpty; // empty file
		Map<Character,String> huffmanCodeMapUS; // US Constitution
		Map<Character,String> huffmanCodeMapWP; // War & Peace

		// PriorityQueue of BinaryTree with data of custom class
		PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQueTestSmall; // small test case
		PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQueTestSingle; // single character edge case
		PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQueTestEmpty; // empty file
		PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQueUS; // US Constitution
		PriorityQueue<BinaryTree<CharacterFrequency>> charAndFreqPriQueWP; // War & Peace

		// Create character|frequency map (involves BufferedReader)
		charAndFreqMapTestSmall = createCharFreqMap(SMALL); 
		charAndFreqMapTestSingle = createCharFreqMap(SINGLE); 
		charAndFreqMapTestEmpty = createCharFreqMap(EMPTY); 
		charAndFreqMapUS = createCharFreqMap(US); 
		charAndFreqMapWP = createCharFreqMap(WP); 

		// Add trees to PQ
		charAndFreqPriQueTestSmall = addTreesToPQ(charAndFreqMapTestSmall);
		charAndFreqPriQueTestSingle = addTreesToPQ(charAndFreqMapTestSingle);
		charAndFreqPriQueTestEmpty = addTreesToPQ(charAndFreqMapTestEmpty);
		charAndFreqPriQueUS = addTreesToPQ(charAndFreqMapUS);
		charAndFreqPriQueWP = addTreesToPQ(charAndFreqMapWP);

		// Form the main HuffmanTree
		createHuffmanTree(charAndFreqPriQueTestSmall);		
		createHuffmanTree(charAndFreqPriQueTestSingle);		
		createHuffmanTree(charAndFreqPriQueTestEmpty);		
		createHuffmanTree(charAndFreqPriQueUS);		
		createHuffmanTree(charAndFreqPriQueWP);		

		// Create map for decoding characters
		huffmanCodeMapTestSmall = getCodes(charAndFreqPriQueTestSmall.peek());
		huffmanCodeMapTestSingle = getCodes(charAndFreqPriQueTestSingle.peek());
		huffmanCodeMapTestEmpty = getCodes(charAndFreqPriQueTestEmpty.peek());
		huffmanCodeMapUS = getCodes(charAndFreqPriQueUS.peek());
		huffmanCodeMapWP = getCodes(charAndFreqPriQueWP.peek());

		// Read characters, write bits (involves BufferedReader & BufferedBitWriter)
		compressHuffman(SMALL, SMALLC, huffmanCodeMapTestSmall); // small test case
		compressHuffman(SINGLE, SINGLEC, huffmanCodeMapTestSingle); // single character edge case
		compressHuffman(EMPTY, EMPTYC, huffmanCodeMapTestEmpty); // empty file
		compressHuffman(US, USC, huffmanCodeMapUS); // US Constitution
		compressHuffman(WP, WPC, huffmanCodeMapWP); // War & Peace

		// Read bits, write characters (involves BufferedWriter & BufferedBitReader)
		decompressHuffman(SMALLC, SMALLD, charAndFreqPriQueTestSmall.peek()); // small test case
		decompressHuffman(SINGLEC, SINGLED, charAndFreqPriQueTestSingle.peek()); // single character edge case
		decompressHuffman(EMPTYC, EMPTYD, charAndFreqPriQueTestEmpty.peek()); // empty file
		decompressHuffman(USC, USD, charAndFreqPriQueUS.peek()); // US Constitution
		decompressHuffman(WPC, WPD, charAndFreqPriQueWP.peek()); // War & Peace

		System.out.println("\nEnd of main");
	}
}
