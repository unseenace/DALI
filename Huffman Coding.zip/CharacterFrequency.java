/**
 * 
 * @author Gui
 * Helper class to hold character and its frequency to pass into Tree data
 */


public class CharacterFrequency {
	private Character character;
	private Integer frequency;
	
	public CharacterFrequency() {
		this.character = null;
		this.frequency = null;
	}
	
	public CharacterFrequency(Character c, Integer f) {
		character = new Character(c);
		frequency = new Integer(f);
	}

	public boolean hasCharacter() {
		return character != null;
	}
	
	public Character getCharacter() {
		return character;
	}

	public void setCharacter(Character character) {
		this.character = character;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}
	
	@Override
	public String toString() {
		return "Character and Frequency of this is: " + character + " | " + frequency; 

	}

}
